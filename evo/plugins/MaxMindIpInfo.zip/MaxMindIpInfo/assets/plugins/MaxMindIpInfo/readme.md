# Информация об IP адресе пользователя с использованием открытых баз MaxMind

Плагин сохраняет в сессии и в куках данные об IP адресе пользователя сайта для дальнейшего использования где бы то ни было

## Features

With this MODX Evolution package a new template variable type is introduced. The template variable could contain a sortable multi item list or a datatable.

Documentation could be found on http://jako.github.io/multiTV/